﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeeExplode : MonoBehaviour
{
    void OnCollisionEnter2D(Collision2D col)
        {
        //if the bee collider touches the bear collider, the bear will explode
        if (col.gameObject.name == "bear") 
            {
            return;
            }
Destroy(col.gameObject);
}
}
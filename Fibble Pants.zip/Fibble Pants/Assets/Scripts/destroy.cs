﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class destroy : MonoBehaviour
{
    //when the bee touches the player, the player will explode.
    void OnTriggerEnter2D(Collider2D col)
    {
         if(col.tag == "Bee")
        {
            Destroy(gameObject);
        }
  
    }
}

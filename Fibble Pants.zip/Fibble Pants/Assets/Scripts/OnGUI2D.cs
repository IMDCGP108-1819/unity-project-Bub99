﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnGUI2D : MonoBehaviour
{
    public static OnGUI2D OG2D;
    public static int score;
    // Start is called before the first frame update
    void Start()
    {
        OG2D = this;
        score = 0;
    }

    private void OnGUI()
    {
        //score position and dimension
        GUI.Label(new Rect(10f, 10f, 1000f, 2000f), "score: " + score);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Movement : MonoBehaviour
{ 
    public float jumpSpeed = 50f;
    public float moveSpeed = 4f;
    private Rigidbody2D rb;
    bool grounded; 
    public Transform groundcheck;
    float playerHeightY;
    public Transform player;
    public float groundRadius = .2f;
    public LayerMask ground;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }


    // Update is called once per frame
    void Update()
    {
        float currentCameraHeight = transform.position.y;
        //player moves using the left/right arrows or the "A"/"D" keys
        float h = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(h * moveSpeed, rb.velocity.y);
        //player height has the same valuse as the y axes
        playerHeightY = transform.position.y;
     //if the player height is bigger than the score, the score will increase in value by 1
        if(playerHeightY > OnGUI2D.score)
        {
            OnGUI2D.score = (int)playerHeightY;
        }

    }

    private void FixedUpdate()
    {
        //the player has boundaries on the left and the right sides of the screen
        float currentCameraHeight = transform.position.y;
        if (transform.position.x < -4.27f)
        {
            transform.position = new Vector3(-4.27f, transform.position.y, 0.0f);
        }
        if (transform.position.x > 4.25f)
        {
            transform.position = new Vector3(4.25f, transform.position.y, 0.0f);
        }
        //if the player touches the plateforms it will continously jump.
        grounded = Physics2D.OverlapCircle(groundcheck.position, groundRadius, ground);

        if (grounded)
        {
            rb.velocity = new Vector2(0, 0);
            rb.AddForce(new Vector2(0, jumpSpeed));
        }
    }
   
}
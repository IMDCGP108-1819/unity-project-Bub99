﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeeMovement : MonoBehaviour
{
    float beeSpeed = 2f;
    bool endPoint;

    private void Start()
    {
        endPoint = false;
    }
    // Update is called once per frame
    void Update()
    {
        if(endPoint == true)
        {
            transform.position += Vector3.right * beeSpeed * Time.deltaTime; 
        }
        else
        {
            transform.position -= Vector3.right * beeSpeed * Time.deltaTime;
        }
        // the bee will continously spawn from the right side after reaching the limit on the left.
        if (transform.position.x < -4.27)
        {
            transform.position = new Vector3(4.27f, transform.position.y, 0.0f);
        }
    }
}

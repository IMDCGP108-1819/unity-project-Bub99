﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    //when the play button is hit, the game will start
    public void PlayGame()
    {
        SceneManager.LoadScene("Game");
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
// return to Main Menu when Back button is hit
public class BackButton : MonoBehaviour
{
    public void Menuback()
    {
        SceneManager.LoadScene("Menu");
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour

{
    public Transform target;

  
    // Update is called once per frame
    void Update()
    {
        //camera position will follow the player's position
        if(target.position.y > transform.position.y)
        {
            transform.position = new Vector3(transform.position.x, target.position.y, transform.position.z);
        }
    }
}

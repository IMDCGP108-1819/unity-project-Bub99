﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InstructionsButton : MonoBehaviour
{
    //when instructions button is hit, the instructions scene is loaded
    public void Insturctions()
    {
        SceneManager.LoadScene("Instructions");
    }
}
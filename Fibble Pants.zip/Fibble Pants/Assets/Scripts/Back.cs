﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// return to Main Menu when Back button is hit
public class Back : MonoBehaviour
{
    public void Menu()
    {
        SceneManager.LoadScene("Menu");
    }
}
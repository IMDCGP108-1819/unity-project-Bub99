﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D col)
    {
        // if the player will touch the bee, the game is over
        if (col.tag == "Bee")
        {
            SceneManager.LoadScene("GameOver");
        }

    }
}
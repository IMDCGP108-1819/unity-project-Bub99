﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeeGenerator : MonoBehaviour
{
    public GameObject beePrefab;
    public int numberOfBees = 50;
    public float beeWidth = 1000f;
    public float minY = 1f;
    public float maxY = 3f;

    // Start is called before the first frame update
    void Start()
    {
        Vector3 spawnPosition = new Vector3();

        for(int i = 0; i < numberOfBees; i++)
        {
            // spawn bees on the y axes.
            spawnPosition.y += Random.Range(minY, maxY);      

            // spawn bees on the x axes.
            spawnPosition.x = Random.Range(-beeWidth, beeWidth);

            Instantiate(beePrefab, spawnPosition, Quaternion.identity);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}